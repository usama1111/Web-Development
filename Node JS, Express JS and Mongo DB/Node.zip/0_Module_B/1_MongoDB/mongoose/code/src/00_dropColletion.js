const mongoose = require('mongoose');

mongoose.connection.collections.users.drop();