alert('Public JS');
console.log('Client JSSSSS')