var myObj = require('./moduleB');



console.log(myObj);