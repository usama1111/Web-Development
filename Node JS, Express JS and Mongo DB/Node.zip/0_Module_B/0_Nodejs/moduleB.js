var myObj = {'abc': 1};

module.exports.xyz = () => {console.log('running func')};